const cloud = require('wx-server-sdk')
cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})
const db = cloud.database()

exports.main = async () => {
  const info = (await db.collection('info').doc('INFO').get()).data
  return {
    errCode: 0,
    errMsg: JSON.stringify(info),
    auth: JSON.stringify({})
  }
}
